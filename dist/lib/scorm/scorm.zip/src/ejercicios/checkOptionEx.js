var notaCheck = 0;
var correctas;
var elegidas;
var q;
var NoTried = 1;
var fbOK, fb0, fb1, fb2, fbNT;
var Intentos = 0;
var soluciones;
var letterArr = new Array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","�","o","p","q","r","s","t","u","v","w","y","z");

function checkOptionEx(){
	NoTried = 1;
	Intentos = 0;
	elegidas = [];
	correctas = [];
	soluciones = [];
	q = [];
	checkOptionXML.each(function(){
		if ($(this).attr("enunciado")) {			
			$("#enunciadoEjer").html($(this).attr("enunciado"));
			$("#instruccionesEjer").html($(this).attr("instrucciones"));
			var imgOne = false;
			if($(this).attr("img")!="" && $(this).attr("img")!= undefined){
					$("#ejercicio").append('<div id="imgOne" style="float:left;width:100%;"><img src="../../js/src/'+ $(this).attr("img")+'" align="center"/></div>');
					imgOne = true;
			}
			
			var sol = $(this).attr("sol");
			soluciones = sol.split(",");
			for (i=0;i<soluciones.length;i++) {
				elegidas[i]=0;
			}
			var contador = 0;
			var listContent = '';
			checkOptionXML.find('CHECK').each(function(){
				var imgLi = "";				
				if($(this).attr("img")!="" && $(this).attr("img")!= undefined){
					imgLi = '<img src="'+ $(this).attr("img")+'" style="vertical-align:middle"/>';					
				}
				contador++;
				var mitexto = $(this).text();
				var liStyle = 'list-style-image: none; list-style: none; padding: 10px; line-height:1.5em;margin-top:1em; position:relative;border: 1px solid #CCCCCC;';
				var liContent = '<li id="opcion' + ("0" + contador).slice (-2) + '" style="'+liStyle+'">';
				if(imgLi != '' && imgLi != undefined){					
					liContent += imgLi;
				}
				liContent += '<input type="checkbox" name="chb[]" value="' + contador + '" style="vertical-align:middle"/><b>'+letterArr[contador-1]+')</b> '+ mitexto + '</li>'
				//$("#ejercicio").append(liContent);
				listContent += liContent;
			});  	
				$("#ejercicio").append('<ul style="float:left;width:100%;margin:0;padding:0;">'+listContent+'</ul>');
				fbOK = checkOptionXML.find('FEEDBACKOK').text();
				fb0 = checkOptionXML.find('FEEDBACK0').text();
				fb1 = checkOptionXML.find('FEEDBACK1').text();
				fb2 = checkOptionXML.find('FEEDBACK2').text();
				fbNT = checkOptionXML.find('NOTRIED').text();
				
				
			if(imgOne){
				
			}
		}
	});
 
 	$('#corregir').append($('<input>').attr("type", "button").attr("id","botCorregir").click(function (){corregirCheck()}));  
	$('#botCorregir').attr("value","Corregir");
	$('#botCorregir').addClass('bot');
	$('#corregir').css('margin-top','50px')

	$('input:checkbox').on('change', function(){
	    NoTried = 0;
	    var indice = $(this).val() - 1;
	    if($(this).is(':checked')){
	        elegidas[indice]=1;
	    } else {
	        elegidas[indice]=0;
	    }
	});
	
	onExEndLoaded();

}


function corregirCheck(){
		 var ii;
		 var bien=1;
		 var nota = 0;
		 var koCheck = 0;
		 var okCheck = 0;
		 var totOkCheck = 0;
	
		 if (NoTried == 1){
			 showFeedback('<b>' + fbNT + "</b>");
		}else{
			 for (i=0;i<soluciones.length;i++){
				 if( soluciones[i] == 1){
					 totOkCheck++;
				}
				if (elegidas[i] != soluciones[i]) { 
					bien = 0; 
					koCheck ++; 
				}else{
					okCheck++;
				}
			}
			notaCheck = ((okCheck-koCheck)*scoreMax)/soluciones.length;	
			if (notaCheck>=NotaCorte){
				showFeedback('<b>' + fbOK + "</b>");
				markCheckSolution();
			}else{
				 if (Intentos == 0) { showFeedback('<b>' + fb0+"</b>");}
				 if (Intentos == 1) {showFeedback('<b>' + fb1+"</b>");}
				 if (Intentos == 2) { 
						showFeedback('<b>' + fb2+"</b>");
						markCheckSolution();
				 }				
				 Intentos++;
				}
			}
}


function markCheckSolution(){	
	for (i=0;i<soluciones.length;i++) {
		if (soluciones[i]==1 ) {
			var nomop="opcion" + ("0" + (i+1)).slice (-2);
			$("[id$=" + nomop + "]").css( "background-color","#A7C7A5" );
		}
		if (soluciones[i]==1 && elegidas[i]==1) {
			var nomop="opcion" + ("0" + (i+1)).slice (-2);
			$("[id$=" + nomop + "]").css( "background-color","#A7C7A5" );
		}
		if (soluciones[i]==0 && elegidas[i]==1) {
			var nomop="opcion" + ("0" + (i+1)).slice (-2);
			$("[id$=" + nomop + "]").css( "background-color","#E4C6C0" );
		}	
	}
	
	$('#botCorregir').remove();
	var theAnsw ="";
	for (i= 0; i <elegidas.length; i++){	
			if(elegidas[i]==1){
				theAnsw += letterArr[i];				
			}
	}
	var checkOk = 0;
	if (notaCheck>=NotaCorte){
		checkOk = 1;
	}			
	exercisesNotes[actvPage] = notaCheck;
	exercisesInter[actvPage]= theAnsw;
	exercisesOk[actvPage]= checkOk;
	sendNota();
}

function fillCheckSolution(){
	addControl("fillCheckSolution")
	for (i=0;i<soluciones.length;i++) {
		if (soluciones[i]==1 ) {
			var nomop="opcion" + ("0" + (i+1)).slice (-2);
			$("[id$=" + nomop + "] input").attr('checked',true);
		}
		elegidas[i] = soluciones[i];
	}
	NoTried = 0

}