///////////////////////////////////////////////////////////////////////////////////////////////////////////
// JavaScript Document
// Gonzalo Monjardín 2014
// gonzalo@alabusa.com
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOGOTIPO PERSONALIZADO
// para versiones con logotipo personalizado en la cabecera poner a true. Ruta imagen ../images/logo.png
var logoPersonalizado = false;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
var exType;
var ejerType;
var objetivo;
var evalDebug = false;
var NotaCorte = 5;
var numIntentos = 2;
var numTries = 0;
var scoreMax = 10;
var theObjetive;
var showSolution = false;
var flash = false;
var hacorregido = false;
var resOk = 0;
var resKo = 0;
var resNo = 0;
var saveData = false;
var nota;
var startDate;
var token = '4eADUu8a';
var audioPermitted;
var pageIsLoaded;

var suspendDataVal;
var suspendData;
var suspendDataItem;
var clickSDPos = 0;
var clickItems = 0;

var scormConn = false;

var ESTADO_VISTO = "browsed";
var ESTADO_COMPLETADO = "completed";
var ESTADO_INCOMPLETO = "incomplete";
var ESTADO_PASADO = "passed";
var ESTADO_FALLADO = "failed";
var ESTADO_NO_INTENTADO = "not attempted";
var ESTADO_CORRECTO = "correct";
var ESTADO_INCORRECTO = "wrong";

var ERROR_API = 'No se ha podido establecer la comunicación con el API.';
var ERROR_SAVE_EVAL = 'No hay conexión con el API. Los resultados no se han guardado.';
var ERROR_FLASH_PLAYER = '<p style="color:red;text-align:center" >Debes tener flash player instalado y permitir su reproducción en el navegador.</p><p style="text-align:center" >Pulsa en la imagen para descargarlo.</p><p style="text-align:center"><a href="http://www.adobe.com/go/getflashplayer" target="_blank"><img src="../js/get_flash_player.gif" alt="Get Adobe Flash player" /></a></p>'

var NO_FLASH_AUDIO_MSN = '<img src="../js/flowplayer/nosound.jpg"/><br/>Para reproducir audios necesitas tener instalado Adobe Flash Player.<br><a href="http://get.adobe.com/es/flashplayer/" target="_blank">Instalar</a>';
var LINKS_OBLIGATORIOS = 'Para dar como completado el apartado es necesario visualizar los enlaces con este icono:<img style="vertical-align:middle" src="../images/recursos/pdfNotSeen.png"/>';

if (undefined == window.test){
	saveData = false;
}else{
	saveData = true;
}


$(document).ready(function(){ 
	/* addControl(tiempo() + ' DOCUMENT READY');	
	 if($('#objetivos').length>0){
		$('#objetivos > li').css('opacity',0);
	}
	browser = detectBrowser();*/
});

$(window).load(function() {
	if(!pageIsLoaded && jsLoaded){
		pageOnloadEnd();
		addControl('1 ' + browser);
	}	
});

window.onload = new function() { 
	if(!pageIsLoaded && jsLoaded){
		pageOnloadEnd();
		addControl('2 ' + browser);
	}
};



function pageOnloadEnd(){
	pageIsLoaded = true;
	addControl(tiempo() + ' WINDOW LOADED');
	manageCarrousel();
	
	
	if($('#objetivos').length>0){
		$('#objetivos > li').css('opacity',0);
	}
	browser = detectBrowser();
	
	if($('.mapa_imagen').length>0){
		$('.mapa').css('visibility','hidden');
		setTimeout(function(){ 
			colocaImgZones();
			$('.mapa').css({visibility:'visible',opacity:0});
			$('.mapa_imagen').each(function() {						
				$(this).hover(
				 function () {
				   $('.mapa').animate({opacity : 1});
				  }, 
				 function () {
					$('.mapa').animate({opacity : 0});
				});
			});
		}, 1000);
	}
	
	if(typeof captivate != 'undefined'){
		swfobject.embedSWF(captivateURL,"myContent", captivateW, captivateH, "9.0.0", "expressInstall.swf", false, false, false,checkSWFLoading);
		//document.getElementById('myContent').style.display = 'none';
	}	
}


function listen(evnt, elem, func) {
    if (elem.addEventListener)  // W3C DOM
        elem.addEventListener(evnt,func,false);
    else if (elem.attachEvent) { // IE DOM
         var r = elem.attachEvent("on"+evnt, func);
         return r;
    }
    else window.alert('No se puede realizar');
}

//listen("load", window, function() { });


function initialize(){	
	addControl("###initialize()");	
	showPreloader('Cargando contenido...');
	creaDivControl();	
	//manageZoomText();	
	//tiene elementos obligatorios
	checkObligLinks();
	
	if(!parent.iframeEx){
		/*$(window).on('unload', function(){
			addControl('ONUNLOAD: ' + onBeforeUnloadAction)						
			var strFun = eval(onBeforeUnloadAction);
			window[strFun]; 
		});*/
		$('body').attr('onunload',onBeforeUnloadAction);
	}
	showDiv('desdeJs');	
	// acepta etiqueta audio ?? /////////////////////////
	var a = document.createElement('audio');
	audioPermitted =  (!!(a.canPlayType && a.canPlayType('audio/mpeg;').replace(/no/, '')));
	
	/* cargo los vídeos */
	if(typeof(video)!='undefined' && typeof(videoFiles)!='undefined'){
		for(i=1;i<=videoFiles;i++){
			loadVideoContent(eval('videoFile'+i),eval('videoDiv'+i));	
		}
	}
	/* cargo los audios */
	if(typeof(audio)!='undefined' && typeof(audioFiles)!='undefined'){		
		for(i=1;i<=audioFiles;i++){
			if(!audioPermitted){
				loadAudios(eval('audioFile'+i),'audioDiv'+i,eval('audioImg'+i));	
			}else{
				$('#sonido'+i).attr('src',eval('audioFile'+i));
			}	
		}
		manageAudio();
	}
		
	if(typeof(videoThinking)!='undefined'){	getToken(videoThinking,token);	}	
	if(typeof(iframeEx)!='undefined'){loadVideoContent(videoTestFile,'VideoTest');}	
	//roundCorners();	
	if($('#slider-id').length>0){
 		try{
			$('#slider-id').codaSlider();
		}catch(e){
			showError(e)
		}
	}
	
	//EVALUACION ////////////////////////////////////////////////////
	if(typeof(evaluacion) !== 'undefined'){
		if(evaluacion){
			showPreloader('Cargando Evaluación...');
			createEvalTest();
			checkNumTries();
		}
	}
	// SIMULADOR /////////////////////////////////////////////////////
	if(typeof(simulador) !== 'undefined'){
		showPreloader('Creando Simulación...');
		if(typeof(simuladorTries) !== 'undefined'){
			numIntentos = simuladorIntentos;
			checkNumTries();	
		}
	}
	// TEST /////////////////////////////////////////////////////
	if(typeof(test) !== 'undefined'){
		if(test){
			showPreloader('Cargando Test...');
			createEvalTest();
		}
	}
	//Ejercicios /////////////////////////////////////////////////////	
	if( typeof(myXmlFile)!== 'undefined'){
		showPreloader('Cargando Ejercicio...');
		loadXML(myXmlFile,false,onExEndLoaded);
	}	
	
	$(document).off('click', '.enlaceGlosario').on('click', '.enlaceGlosario',function() { 
		openGlosario($(this).text());
	});
	
	$(document).off('click', '.enlaceWeb').on('click', '.enlaceWeb',function(e) {
		e.preventDefault();
		openUrl($(this).attr('href'));
	});
	
	$(document).off('click', '.enlacePfd , .enlaceZip').on('click', '.enlacePdf, .enlaceZip',function(e) {
		e.preventDefault();
		openPdf($(this).attr('href'));
	});
	
	// Efecto ampliación imagen al pasar por encima
	if($('.imgBigOver').length>0){		
		$('.imgBigOver').each(function() {		
			$(this).css({
				width:$(this).attr('data-width'), height: $(this).attr('data-height')
			});	
			percent = 1;
			add_width = (percent*$(this).parent().width())+'px';
			
			$(this).hover(
				function() {
					$(this).animate({width : '+='+add_width, height: '100%'});
				}, function() {
					$(this).animate({width :$(this).attr('data-width'), height: $(this).attr('data-height')});
			});	
		});	
	}
	
	alumno();	
	getSpaceDimensions(); 
	if($('#objetivos').length > 0){
		showObjetives();	
	}		
	//$("body").fadeIn( "slow", function() {
		showDiv();		
		initAnims();		
		if(typeof(evaluacion) == 'undefined' && typeof(test) == 'undefined' && typeof(myXmlFile)== 'undefined' || ejerType == 'seleccionaTexto'){				
			setTimeout(function(){ 
				$('.caja').css('visibility','visible');
				hidePreloader();
			}, 500);
		}
	//});
}


function onExEndLoaded(){
	addControl(' - onExEndLoaded - ')
	$('.caja').css('visibility','visible');
	
	hidePreloader();
}


// inicializo
function initScorm(){	
	var result = doLMSInitialize();
	addControl('## INIT SCORM ## : ' + result);
	if(result!='true'){ 
		if(!parent.iframeEx){
			showError('# '+ERROR_API);
		}
	}else{
		scormConn = true;
		var estado01 = doLMSGetValue('cmi.core.lesson_status').charAt(0).toLowerCase();
		var estado02 = ESTADO_NO_INTENTADO.charAt(0).toLowerCase();
		addControl('ESTADO 01 : ' + estado01 + '  ESTADO 02 : ' + estado02)
		if (estado01 == estado02){			
			doLMSSetValue('cmi.core.lesson_status',ESTADO_INCOMPLETO);
			doLMSCommit();
			addControl('## set incomplete on start');
		}	
		//alert(doLMSGetValue('cmi._version'));
		startTimer();
	}
	initialize();
	return true;
}

//finalizo
function endScorm(){
	addControl('## END SCORM 01');
	if(scormConn){
		computeTime();
		doLMSCommit();
		doLMSFinish("");
		scormConn = false;
		addControl('## END SCORM 02');
	}
}


function setLessonStatus(){	
		addControl('## scormconn : ' + scormConn);
		if(scormConn){
			var estado01 = doLMSGetValue('cmi.core.lesson_status').charAt(0).toLowerCase();
			var estado02 = ESTADO_COMPLETADO.charAt(0).toLowerCase();
			addControl('## setLessonStatus 01 ' + estado01 + '   02 : ' + estado02);
			
			if(typeof objClickItems != 'undefined'){				
				var ok = 0;
				var totItems = suspendDataItem.length;
				for(i=0;i<totItems;i++){
					if(suspendDataItem[i] == '1'){ok++;}
				}
				if(ok >= clickItems){
					var state = ESTADO_COMPLETADO;
					var objState = ESTADO_PASADO;
				}else{
					var state = ESTADO_INCOMPLETO;
					var objState = ESTADO_FALLADO;
				}
				var nota = parseInt((ok*100)/totItems);
				var notaF = parseInt(nota);
				var notaAnt = parseInt(doLMSGetValue('cmi.core.score.raw'));
				if(nota <= notaAnt){
					notaF = notaAnt;
				}
				doLMSSetValue('cmi.core.lesson_status',state);
				doLMSSetValue('cmi.core.score.raw',notaF);						
				doLMSSetValue('cmi.core.score.max',100);
				doLMSSetValue('cmi.core.score.min','0');						
				addControl(' NOTA : ' + nota);
				var z = doLMSGetValue('cmi.objectives._count');
				doLMSSetValue('cmi.objectives.'+z+'.id',objClickItems);
				doLMSSetValue('cmi.objectives.'+z+'.score.raw',nota);
				doLMSSetValue('cmi.objectives.'+z+'.score.max',100);
				doLMSSetValue('cmi.objectives.'+z+'.score.min','0');					
				doLMSSetValue('cmi.objectives.'+z+'.status',objState);
				addControl(clickSDPos + 'suspendDataItem : ' + suspendDataItem + '  -  ' + suspendDataItem.toString().replace(/\,/g,""));
				
				var linkVal = objClickItems + ':' + suspendDataItem.toString().replace(/\,/g,"");				
				suspendDataVal[clickSDPos] = linkVal;
				
				doLMSSetValue('cmi.suspend_data',suspendDataVal);
				addControl('suspendDataVal : ' + suspendDataVal)
			
			}else{
			
				if (estado01 != estado02){			
					doLMSSetValue('cmi.core.lesson_status',ESTADO_COMPLETADO);
					addControl('Marco como completado 1er acceso');
				}
			}
			endScorm();
		}
}

function checkObligLinks(){
	
	if(typeof objClickItems!= 'undefined'){
		var linksVistos = 0;
		suspendDataVal = doLMSGetValue('cmi.suspend_data');	
		clickItems = $('.obligatorio').length;
		addControl('clickItems : ' + clickItems + ' - '+typeof suspendDataVal)
		addControl('suspendDataVal: ' + suspendDataVal);
		if (suspendDataVal == ""){			
			suspendData = new Array();
			suspendDataItem = new Array();
			suspendDataVal = new Array();
			var presuspend = "";
			for(i=0;i<clickItems;i++){
				presuspend += 0;
				suspendDataItem.push(0);
				$('.obligatorio').eq(i).attr('rel-pos',i);
				var url = 'url(../images/recursos/pdfNotSeen.png)'	;
				$('.obligatorio').eq(i).css({
					'background-image':url							
				})	
			}
			suspendData.push(''+objClickItems + ':' + presuspend);
			suspendDataVal.push(objClickItems + ':' + presuspend);
			doLMSSetValue('cmi.suspend_data',suspendData);			
			doLMSCommit();
			addControl('A - ' + suspendData);		
		
		}else{			
			suspendData = new Array();
			//suspendDataItem = new Array();
			var sd = suspendDataVal.split(',');
			suspendDataVal = sd;
			addControl('sdLeng '+sd.length)
			for(i=0;i<sd.length;i++){
				suspendData.push(sd[i].split(','));
			}
			addControl(suspendData.length + ' suspendData : ' + suspendData);
			
			for(i=0;i<suspendData.length;i++){
				addControl('suspendData[i]' + suspendData[i]);
				var obj = suspendData[i].toString().split(':');
				addControl(obj[0] + objClickItems)
				if(obj[0].toLowerCase() == objClickItems.toLowerCase()){
					suspendDataItem = obj[1];
					addControl("EXISTE : " +suspendDataItem)
					clickSDPos = i;
				}
				
			}
			
			suspendDataItem = suspendDataItem.split('');
			for(i=0;i<suspendDataItem.length;i++){
				$('.obligatorio').eq(i).attr('rel-pos',i);
				if(suspendDataItem[i] == 1){
					linksVistos ++; 
					var url = 'url(../images/recursos/pdfSeen.png)';
				}else{
					var url = 'url(../images/recursos/pdfNotSeen.png)';
				}
				$('.obligatorio').eq(i).css({
					'background-image':url							
				})	
			}
			addControl('B - ' + suspendDataItem);
		}		
		
		addControl(typeof suspendDataItem.length + '-' + suspendDataItem.length);
		addControl(typeof linksVistos.length + '-' + linksVistos);
		
		var linksLeft = suspendDataItem.length - linksVistos;
		if(linksLeft > 0 ){
			createAlert(LINKS_OBLIGATORIOS + '<br>Faltan '+linksLeft +' de '+ suspendDataItem.length+' enlaces por abrir.','Información');
		}	
		
		$(document).off('click', '.obligatorio').on('click', '.obligatorio',function() { 
			checkLinkItems($(this));
		});
		addControl(linksLeft + 'de' + suspendDataItem.length);
		addControl('suspendDataItem : ' +suspendDataItem);
	}			
}

function checkLinkItems(obj){
	var pos = parseInt(obj.attr('rel-pos'));
	suspendDataItem[pos] = 1;
	obj.css({'background-image':'url(../images/recursos/pdfSeen.png)'});
	addControl(pos + 'checkLinkItems: ' + suspendDataItem);
}

function onUnloadVideoScormEvent(){	
		if(scormConn){
			var estado01 = doLMSGetValue('cmi.core.lesson_status').charAt(0).toLowerCase();
			var estado02 = ESTADO_COMPLETADO.charAt(0).toLowerCase();
			videoPercent = Math.round(videoPercent)
			addControl('## onUnloadVideoScormEvent 01 ' + estado01 + '   02 : ' + estado02 + ' percent : ' + videoPercent + ' ' + typeof videoPercent);
			
			if (estado01 != estado02){
				if(videoPercent>=98){
					videoPercent = 100
					doLMSSetValue('cmi.core.lesson_status',ESTADO_COMPLETADO);
					var stadoObj = ESTADO_PASADO;
				}else{
					doLMSSetValue('cmi.core.lesson_status',ESTADO_INCOMPLETO);
					var stadoObj = ESTADO_FALLADO;
					}
				doLMSSetValue('cmi.core.score.raw',videoPercent);						
				doLMSSetValue('cmi.core.score.max',100);
				doLMSSetValue('cmi.core.score.min','0');
				
				if(typeof videoObjetive != 'undefined'){
					var z = doLMSGetValue('cmi.objectives._count');
					doLMSSetValue('cmi.objectives.'+z+'.id',videoObjetive);
					doLMSSetValue('cmi.objectives.'+z+'.score.raw',videoPercent);
					doLMSSetValue('cmi.objectives.'+z+'.score.max',100);
					doLMSSetValue('cmi.objectives.'+z+'.score.min','0');					
					doLMSSetValue('cmi.objectives.'+z+'.status',stadoObj);
				}
			}
			endScorm();
		}
}


function setPracticeStatus(){
	if(scormConn){
		var nota = Math.round(notaPractice);		
		var estado = doLMSGetValue('cmi.core.lesson_status').charAt(0);
		var z = doLMSGetValue('cmi.objectives._count');
		var notaIni = getNota();
		if(estado == 'I' || estado == 'i'  || estado == 'n' || estado == 'N'){
			doLMSSetValue('cmi.core.lesson_status',ESTADO_COMPLETADO);
		}
		
		if(nota!= undefined){
		  if (notaIni!="") {
			  if(nota>notaIni){
				  doLMSSetValue("cmi.core.score.raw",nota);	
			  }
		  }else{
			  doLMSSetValue("cmi.core.score.raw",nota);
		  }
		  
		  doLMSSetValue('cmi.objectives.'+z+'.id',theObjetive);
		  
		  if(nota>=NotaCorte){
			  doLMSSetValue('cmi.objectives.'+z+'.status',ESTADO_COMPLETADO);
		  }else{
			  doLMSSetValue('cmi.objectives.'+z+'.status',ESTADO_FALLADO);
		  }
		  doLMSSetValue('cmi.objectives.'+z+'.score.raw',nota);
		  doLMSSetValue('cmi.objectives.'+z+'.score.max',scoreMax);
		  doLMSSetValue('cmi.objectives.'+z+'.score.min','0');	
	  
		}else{			
		  doLMSSetValue('cmi.objectives.'+z+'.id',theObjetive);
		  doLMSSetValue('cmi.objectives.'+z+'.status',ESTADO_NO_INTENTADO);
		  doLMSSetValue('cmi.objectives.'+z+'.score.raw','0');
		  doLMSSetValue('cmi.objectives.'+z+'.score.max',scoreMax);
		  doLMSSetValue('cmi.objectives.'+z+'.score.min','0');
		}
			
		doLMSSetValue('cmi.core.score.max',scoreMax);
		doLMSSetValue('cmi.core.score.min','0');
		endScorm();
	}
}

function setDemoStatus(){
	setLessonStatus();	
}


function fix(fixNumber, decimalPlaces){
   var div = Math.pow(10,decimalPlaces);
   fixNumber = Math.round(fixNumber * div) / div;
   return fixNumber;
}



function alumno(){
	addControl('ALUMNO :' + logoPersonalizado)
	if(scormConn){		
		nombre = doLMSGetValue("cmi.core.student_name");
		var str = nombre.split(",");
		var alumno = str[1] + " " + str[0]
		$('#alumno').empty();
	}else{		
		if(!parent.iframeEx){
			var alumno = 'No identificado';			
		}				
	}
	if(logoPersonalizado){			
			$('#alumno').parent().find('img').remove();
			$('.cabtabla_lapiz').css({padding:0,width:'auto'});
			$('.tit_ud_cap').css({width:'auto'});
			alumno = '<img src="../images/ico_alumno.gif" alt="Alumno" style="vertical-align:middle;float:none;"/>'+alumno + '<img src="../images/logo.png" style="float:none;margin-left:5px;"/>';
	}
	$('#alumno').append(alumno);
	if(parent.iframeEx){
		$('#alumno').html(parent.$('#alumno').html());
	}
	return true;	
	//return str[1] + " " + str[0];
}



//****************************************************************************************************************************************
// GESTION DE TIEMPOS
//****************************************************************************************************************************************
function startTimer(){
   startDate = new Date().getTime();
}

function computeTime(){
   if ( startDate != 0 )  {
      var currentDate = new Date().getTime();
      var elapsedSeconds = ((currentDate - startDate) / 1000);
      var formattedTime = convertTotalSeconds (elapsedSeconds);
   } else {
      formattedTime = "00:00:00";
   }  
  	doLMSSetValue ("cmi.core.session_time", formattedTime);
	return true;
}

/*******************************************************************************
** this function will convert seconds into hours, minutes, and seconds in
** CMITimespan type format - HHHH:MM:SS.SS (Hours has a max of 4 digits &
** Min of 2 digits
*******************************************************************************/
function convertTotalSeconds(ts){
   var sec = (ts % 60);
   ts -= sec;
   var tmp = (ts % 3600);  //# of seconds in the total # of minutes
   ts -= tmp;              //# of seconds in the total # of hours
   // convert seconds to conform to CMITimespan type (e.g. SS.00)
   sec = Math.round(sec*100)/100;
   var strSec = new String(sec);
   var strWholeSec = strSec;
   var strFractionSec = "";
   if (strSec.indexOf(".") != -1){
      strWholeSec =  strSec.substring(0, strSec.indexOf("."));
      strFractionSec = strSec.substring(strSec.indexOf(".")+1, strSec.length);
   }

   if (strWholeSec.length < 2){
      strWholeSec = "0" + strWholeSec;
   }
   strSec = strWholeSec; 
   if ((ts % 3600) != 0 )
      var hour = 0;
   else var hour = (ts / 3600);
   if ( (tmp % 60) != 0 )
      var min = 0;
   else var min = (tmp / 60);
	
   if ((new String(hour)).length < 2)
      hour = "0"+hour;
   if ((new String(min)).length < 2)
      min = "0"+min;

   var rtnVal = hour+":"+min+":"+strSec;	
   return rtnVal;
}


