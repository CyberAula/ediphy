///////////////////////////////////////////////////////////////////////////////////////////////////////////
// JavaScript Document
// Gonzalo Monjardín 2014
// gonzalo@alabusa.com
// modificado para scorm stricto y plantillas responsive.
///////////////////////////////////////////////////////////////////////////////////////////////////////////


function onUnloadEjerScormEvent(){	 
	if(!theObjetive){
		theObjetive = objetivo;
	}
	addControl("corregir: " + theObjetive + " - " + hacorregido)	
	if (hacorregido == false){
		doLMSSetValue('cmi.core.lesson_status',ESTADO_COMPLETADO);
		var n = doLMSGetValue("cmi.objectives._count");
		doLMSSetValue('cmi.objectives.'+n+'.id',theObjetive);
		doLMSSetValue('cmi.objectives.'+n+'.status',ESTADO_NO_INTENTADO);
		doLMSSetValue('cmi.objectives.'+n+'.score.raw','0');
		doLMSSetValue('cmi.objectives.'+n+'.score.max',scoreMax);
		doLMSSetValue('cmi.objectives.'+n+'.score.min','0');
		endScorm();
		hacorregido = true; // forzamos para que no de error en el onBeforeUnload
	}	
}

function marcarCheckListEx(){
	for (i=1; i<=res.length; i++){
		var lista=document.getElementById("r"+i);
 		lista.options[res[i-1]].selected = 'selected';
	}
}


function checkListEx(){	
	var nota = 0;
	var ok = 0;
	var pos = 0;
	var isOk="";
	var resp="";
	var respMulti="";
	addControl("checkListEx");	
	
	for (i=0; i<res.length; i++){		
			var valor = '';			
			if(i>0){resp+=","}			
			var okStatus = false;
				
				if(res[i].length>1){
					var sol = res[i].split(",");
					ok=0;
					respMulti = "";
					for(k=0;k<=sol.length-1;k++){							
						pos ++;
						valor = eval('document.EF.r'+(pos)+'[document.EF.r'+(pos)+'.selectedIndex].value');
						var control = pos + "  " + sol[k] + ": " + valor;
						if(debug){
						document.getElementById("debugger").style.display = "block";
						}
						if (valor==sol[k]){
							ok++;	
							control +=" ok";
							document.getElementById('r'+(pos)+'').className='right';					
						}else{
							document.getElementById('r'+(pos)+'').className='wrong';
							
						}
						respMulti += valor;
						if(k<sol.length-1){
							respMulti +="-";
						}else{
							respMulti + ",";
							}
						//addControl(control);
					}
					
					resp += respMulti;			
					//alert(i + "-" + ok)
					if(ok>=(sol.length/2)){
						isOk += 1;	
						if(i>0){isOk+=","}
						addControl("OK: " + isOk)
						nota = nota  + (10/res.length);
					}else{
						isOk += 0;
						}
				}else{
					valor =  valor + eval('document.EF.r'+(i+1)+'[document.EF.r'+(i+1)+'.selectedIndex].value');	
					resp += eval('document.EF.r'+(i+1)+'[document.EF.r'+(i+1)+'.selectedIndex].value');
					
					if(i>0){isOk+=","}
					if(valor==res[i]){
						okStatus = true;
						isOk +=1;
						ok++;
					}else{
						isOk += 0;
					}
					if(okStatus){						
						document.getElementById('r'+(i+1)+'').className='right';					
					}else{
						document.getElementById('r'+(i+1)+'').className='wrong';
					}
				}
				if(document.getElementById("just"+(i+1))){
					document.getElementById("just"+(i+1)).className = "visible";
				}
		}
		
	nota = (ok*10) /(res.length);
	nota = Math.round(nota);
	if(nota>=NotaCorte){
		var imagen = eval('document.EF.G1');
		imagen.alt = "verdadero";
		imagen.src = "../images/check_true.gif";
	}else{
		var imagen = eval('document.EF.G1');
		imagen.alt = "falso";
		imagen.src = "../images/check_false.gif";				
	}
	var thePdf = document.getElementById("solPdf");	
	if(thePdf){		
		document.getElementById("solPdf").className = "visible";
	}
	grabaejercicio(Math.round(nota),resp,isOk,NotaCorte);
}


		
function grabaejercicio(_val,_inter,_resOk,_corte){		
	hacorregido = true;	
	var nota = 0;
	if(!theObjetive){
		theObjetive = objetivo;
	}
	if(_corte!=undefined){
		NotaCorte = _corte;
	}
	addControl("grabaejercicio:" + theObjetive);
	interVals = _inter.split(",");
	okVals = _resOk.split(",");	
	addControl("interVals:" + interVals.length);
	
	// NOTA ///////////////////////////////////////////////////////
	nota = parseInt(_val);			
	if (nota>=scoreMax){
		nota = scoreMax;
	}else{
		nota = nota;
	}	
	
	if (nota < 0){
		nota = 0;
	}	
	nota = fix(nota,2);  
	var notaf = nota.toString();
	notaf = notaf.replace(',','.');		
	/////////////////////////////////////////////////////////////
	
	var estado = doLMSGetValue('cmi.core.lesson_status');
	var notaant = doLMSGetValue('cmi.core.score.raw');	

	if (notaant == ''){
		notaant = 0;
	}	
	addControl('SAVE DATA: ' + saveData)
	if(saveData){
		//if(nota>=_corte){
		doLMSSetValue('cmi.core.lesson_status',ESTADO_COMPLETADO);
		//}else{
			//doLMSSetValue('cmi.core.lesson_status',ESTADO_INCOMPLETO);
	//}	
		if (parseFloat(notaant) >= parseFloat(nota)){
			doLMSSetValue('cmi.core.score.raw',notaant);
		}else{
			doLMSSetValue('cmi.core.score.raw',notaf);
		}
		doLMSSetValue('cmi.core.score.max',scoreMax);
		doLMSSetValue('cmi.core.score.min','0');
			
		// OBJETIVOS //////////////////////////////////////////////////
		var z = doLMSGetValue('cmi.objectives._count');
		doLMSSetValue('cmi.objectives.'+z+'.id',theObjetive);
		doLMSSetValue('cmi.objectives.'+z+'.score.raw',notaf);
		doLMSSetValue('cmi.objectives.'+z+'.score.max',scoreMax);
		doLMSSetValue('cmi.objectives.'+z+'.score.min','0');	
			
		if(parseFloat(nota) >= parseFloat(NotaCorte)){
			var stadoObj = ESTADO_PASADO;
		}else{
			var stadoObj = ESTADO_FALLADO;
		}
		doLMSSetValue('cmi.objectives.'+z+'.status',stadoObj);
			
		// INTERACCIONES //////////////////////////////////////////////				
		var numOk = 0;
		addControl("INTERACCIONES " + interVals.length)
		addControl("OK " + okVals);
		
		for (i=0;i<interVals.length;i++){
				var interactNo = 'P'+i;
				if(i<10){interactNo = 'P0'+i;}
				
				if(interVals[i] != "undefined" || iframeEx){
					var n = doLMSGetValue("cmi.interactions._count");	
					doLMSSetValue('cmi.interactions.'+n+'.id',interactNo);
					if(typeof _xmlFile!= undefined){						
						doLMSSetValue('cmi.interactions.'+n+'.type','fill-in');
					}else{
						doLMSSetValue('cmi.interactions.'+n+'.type','choice');
					}							
					doLMSSetValue('cmi.interactions.'+n+'.weighting',1);
					doLMSSetValue('cmi.interactions.'+n+'.objectives.'+z+'.id',theObjetive);
					doLMSSetValue('cmi.interactions.'+n+'.student_response',interVals[i]);			
					
					if (okVals[i]==1){
						var estadoInt = ESTADO_CORRECTO;
						numOk ++;
					}else{
						var estadoInt = ESTADO_INCORRECTO;						
					}
					doLMSSetValue('cmi.interactions.'+n+'.result',estadoInt);
					//addControl(" n : " + n + " OBJ: " + theObjetive + " - " + interVals[i] + " - " + okVals[i]);
					
				}				
		}					
		doLMSCommit();		
		//if(!parent.iframeEx){
			endScorm();
		//}
		addControl("Nota corte:"+NotaCorte+" NOTA" + notaf +" NotaAnt:"+notaant+" OBJ:" +theObjetive);
	}
	
}

function hideJustificacion(){
	for (i=0; i<res.length; i++){
		if(document.getElementById("just"+(i))){
			document.getElementById("just"+(i)).className = "oculto";
		}
		if(document.getElementById("J"+(i))){
			document.getElementById("J"+(i)).className = "oculto";
		}
	}
	
}

function showJustificacion(){
	for (i=0; i<res.length; i++){
		if(document.getElementById("just"+(i))){
			document.getElementById("just"+(i)).className = "visible";
		}
		
		if(document.getElementById("J"+(i))){
			document.getElementById("J"+(i)).className = "visible";
		}
	}
	
}