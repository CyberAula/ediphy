Dali.Visor.Plugins["ListaNumerada"] = function (){
  return {
    getRenderTemplate: function (state) {
      var colors = ['verde', 'morado', 'azul', 'rosa', 'naranja', 'rojo'];
      let currentColor = state.colors[0];
      var template = '<div class="desplVert" style=" margin-top:30px; margin-bottom:20px; width:100%; max-width:500px">'
      +'<div id="primerdiv">'
      +'<div class="izq_jq ' + currentColor + '">1</div>'
      +'<div class="container0 ' + currentColor + 'der">'
      +'<plugin plugin-data-key="numList_0" plugin-data-resizable  />'
      +'</div>'
      +'</div>'
      +'<div  class="desplVert1 container">'

      for (var i = 0; i < state.nBoxes-1; i++){
        currentColor = state.colors[i+1];
        template += '<div style="display: none;" class="ocultar" data-id="div_' + (i+1) + '" >'
        +'<div class="izq_jq ' + currentColor + '">' + (i+2) + '</div>'
        +'<div class="container0 ' + currentColor + 'der">'
        +'<plugin plugin-data-key="numList_' + (i+1) + '"  plugin-data-resizable />'
        +'</div>'
        +'</div>'
      }
      
      template +='</div>'
      + '<p data-pos="0" onClick="$dali$.showDiv( )"   data-length="' + state.nBoxes + '" class="showLista"    >+</p>'
      + '</div>'

      return template;

    },
    showDiv: function(event, element, parent){
      var dataLength = parseInt(element.getAttribute('data-length'));
      var dataPos = parseInt(element.getAttribute('data-pos'));
       if (dataPos < dataLength) {
        $( parent ).find('.desplVert1 > div:eq(' + dataPos + ')').show("slow");
        var nextElem = parseInt(dataPos + 1);
        element.setAttribute('data-pos', nextElem);
      }
      if (dataPos >= dataLength - 2) {
        element.classList.add("hidden");
      } 
       
    }
  }
}
