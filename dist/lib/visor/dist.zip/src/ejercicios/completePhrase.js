
function Shuffle(o) {
	for(var j, x, i = o.length; i; j = parseInt(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
	return o;
};

var respuestasPhrase = [];
var respuestasdesordenado =[];
var placebos =[];
var intentosPhrase = 0;
var feedback = [];
var feeedbackOk,feedbacknotried;
var phraseInteractions;
var phraseOkVals;

function fraseEx(){	
	resetCompletePhrase();
	enunciado = fraseXML.attr('enunciado');	
	instrucciones = fraseXML.attr('instrucciones') + '<span style="text-align:center;display:block;">';	
	$('#enunciadoEjer').html(enunciado);
	$('#instruccionesEjer').html(instrucciones);
	$('<div></div>').attr( 'id','salida').appendTo('#ejercicio');
	$('<div></div>').attr( 'id','opciones').appendTo('#ejercicio');
	$('#corregir').append($('<input name="corrige" id="botCorregir" value="Resultados" class="bot" type="button"/>').click(function (){corregirFrase()}));  
	$('#corregir').css('margin-top','50px')
	prepararFrase(fraseXML[0]);	
}


function prepararFrase(xml){	
		var salida="";
		var anchoDrop,altoLine;
		var tipo, enunciado,cuestion,instrucciones,tipo;	
			tipo = fraseXML.attr('tipo');
			enunciado = fraseXML.attr('enunciado');
			instrucciones = fraseXML.attr('instrucciones');							
			anchoDrop = fraseXML.attr('anchoDrop');
			altoLine = fraseXML.attr('altoLine');			
			fraseXML.find("ITEMS ITEM OPTION").each(function () {
					cuestion = $(this)[0].childNodes;	
					$(this).children().each(function (){
						if ($(this).text()!=""){
							respuestasPhrase.push($(this).text());
							respuestasdesordenado.push($(this).text());		
						}
					});					
			});			
			fraseXML.find("PLACEBO ITEM").each(function () {					
					respuestasdesordenado.push($(this).text());						
			});		
			fraseXML.find("FEEDBACKOK").each(function () {
					feeedbackOk = $(this).text();					
			});
			fraseXML.find("NOTRIED").each(function () {
					feedbacknotried = $(this).text();					
			});
			var FEEDBACKBUCLE = "FEEDBACK";
			for (var i=0;i<=numIntentos;i++) {
				var	FEEDBACKIteracion= FEEDBACKBUCLE+ i;
				fraseXML.find(FEEDBACKIteracion).each(function () {					
					feedback.push($(this).text());					
				});		
			}
			fraseXML.find("ITEMS ITEM JUSTIFICACION").each(function () {
					justificacion = $(this).text();					
			});	
			respuestasdesordenado = Shuffle(respuestasdesordenado);				
			$('#salida').append(salida);	
			$('#instrucciones').append(instrucciones);
			$.each(respuestasdesordenado, function( index, value ) {		
				 $('<div>' + value + '</div>').attr( 'id', 'card'+index ).data( 'palabra', value).appendTo( '#opciones' ).draggable( {
				  containment: '#content',
				  stack: '#salida div',
				  cursor: 'move',
				  revert: true
				} );				
			});			
			var salto =0;
			var parrafo =$('<div class="parrafo"></div>') ;
			$.each(cuestion, function( index, value ) {		
				if (value.nodeName!="ITEM"){		
					var textosinespacios;
					if (value.nodeType==3){
						if (value.text!=undefined){
							textosinespacios=value.text.split(" ");
						}
						else{
							textosinespacios=value.textContent.split(" ");
						 }
						 $.each(textosinespacios, function( index, value ) {								
								$('<div>' +  value+ '&nbsp;</div>').data('palabra',value).appendTo(parrafo);															
						 });
					 };
					 if (value.nodeType==1){
						if (value.nodeName =="br"){
							$(parrafo).appendTo("#salida");
							parrafo = $('<div class="parrafo"></div>') ;
						 }
					 }
				}else{
				 $('<div></div>').appendTo($('<div></div>').attr('class','contenedor').attr('id','cont'+index).appendTo( parrafo )).droppable( {
						accept: '#opciones div',
						hoverClass: 'hovered',
						drop:  handleCardDrop,
						out: handleOut
					});
				}
			});
			$(parrafo).appendTo("#salida");
			$("#enunciado").append(enunciado);			
			$("#salida .parrafo div").each(function(){
				if (!$(this).hasClass("ui-droppable")){
					$(this).css("height",altoLine);				
				}
			});			
			$("#salida .ui-droppable").css("width",anchoDrop);			
			$("#opciones .ui-draggable").css("width",anchoDrop);
			onExEndLoaded();
			return true;
	};
	
function handleOut( event, ui ) {
	addControl($(this).data("id") + " - " + ui.draggable.attr('id'))
	if ($(this).data("id") == ui.draggable.attr('id')){	
		$(this).removeData();
		$(ui.helper).mouseup(function() {	
			ui.draggable.css({"left": 0,"top": 0});
		});
	}	
}

function handleCardDrop( event, ui ) {
	$(this).data( 'palabra',ui.draggable.data( 'palabra'));
	$(this).data( 'id',ui.draggable.attr( 'id'));	
	ui.draggable.position( { of: $(this), my: 'left top', at: 'left top' } );
    ui.draggable.draggable( 'option', 'revert', false );
}

function mostrarResultados(){
	$("#opciones").css("display","none");
	$("#salida div.ui-droppable").each(function( index, value ) {		
		$(this).html(respuestasPhrase[index]);
		if ($(this).data("palabra")==respuestasPhrase[index]){
			$(this).addClass("correcto");
		}else{
			$(this).addClass("incorrecto");
		}		
	});	
}

function fillFraseSolution(){
	$("#salida div.ui-droppable").each(function( index, value ) {		
		$(this).html(respuestasPhrase[index]);	
		$(this).data("palabra",respuestasPhrase[index]);
		respuestasPhrase[index] = $(this).data("palabra");
	});	
	$('#opciones').hide();
}

function devolverNota(nota_entero){
	var salida;	
	var nota = nota_entero.toString();
	if (nota.indexOf(".")==-1){
			salida = nota;
	}else{
		salida = nota.split(".")[0];
		salida = salida + ".";		
		if (nota.split(".").length>1){				
			salida = salida + nota.split(".")[1].substring(0,2);
		}
	}	
	return salida;
}

var notaFrase;
function mostrarResumen(tries, aciertos){
	var numopciones = respuestasPhrase.length;
	var nota = parseInt(scoreMax*aciertos/numopciones) ;
	notaFrase = nota;
	showResults(aciertos,numopciones,tries,devolverNota(nota));
	var theAnsw ="";
	for (i= 0; i <phraseInteractions.length; i++){	
			theAnsw += phraseInteractions[i];			
			if(i<phraseInteractions.length-1){
				theAnsw += " - "
			}
		}
	$('#corregir').empty();	
	exercisesNotes[actvPage] = devolverNota(nota);
	exercisesInter[actvPage]= theAnsw;
	exercisesOk[actvPage]= phraseOkVals;
	sendNota();
	return true;
}

function corregirFrase(){
	addControl('corregirFrase');
	var aciertos=0;	
	phraseInteractions = new Array();
	phraseOkVals = new Array();
	done = false;
	$("#salida div.ui-droppable").each(function( index, value ) {	
		phraseOkVals[index] = 0;
		if ($(this).data("palabra")==respuestasPhrase[index]){
			aciertos = aciertos +1;
			phraseOkVals[index] = 1;
		}
		phraseInteractions[index]=(index+1) + '-' + $(this).data("palabra");
		if ($(this).data("palabra")==undefined){
			falta = 1;
			phraseInteractions[index]='';
		}else{done = true}
	});
	var _txt;
	var isOk = false;
	addControl('DONE' + done);
	if(done){
		var numopciones = respuestasPhrase.length;
		var nota = parseInt(scoreMax*aciertos/numopciones) ;
		if (nota < NotaCorte){	
		addControl('1')
			_txt =  feedback[intentosPhrase];	
		}else{
			addControl('2')
			_txt = feeedbackOk;
			isOk = true;
		}	
		
		intentosPhrase = intentosPhrase+1;
		if (intentosPhrase  >= numIntentos || isOk==true){
				addControl("Muestro Resultados")
				mostrarResultados();
				mostrarResumen(intentosPhrase,aciertos);
		}
		//if (aciertos < (respuestasPhrase.length/2)){
		
		showFeedback('<b>' +_txt + '</b>');
	}else{
		showFeedback('<b>' + feedbacknotried + '</b>');
	}
}


function resetCompletePhrase(){
	respuestasPhrase = [];
	respuestasdesordenado =[];
	placebos =[];
	intentosPhrase = 0;
	feedback = [];
}