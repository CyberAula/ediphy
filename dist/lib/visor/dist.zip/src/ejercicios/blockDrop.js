var intentosBlock = 0;
var totDrops = 0;
var fbOK, fb0, fb1, fb2, fbNT,fbFinal;
var dropsTxt = new Array();
var dragsPos = new Array();		
var responsesBloques = new Array();
var responsesOkBloques = new Array();	
var numOk = 0;

function bloquesEx(){
	addControl("bloquesEx");	
	fbOK, fb0, fb1, fb2, fbNT;
		if (bloquesXML.attr("enunciado")) {
			var mitexto = $(this).text();
			$("#enunciadoEjer").html(bloquesXML.attr("enunciado"));
			$("#instruccionesEjer").html(bloquesXML.attr("instrucciones"));
		}
			fbOK = bloquesXML.find('FEEDBACKOK').text();
			fb0 = bloquesXML.find('FEEDBACK0').text();
			fb1 = bloquesXML.find('FEEDBACK1').text();
			fb2 = bloquesXML.find('FEEDBACK2').text();
			fbNT = bloquesXML.find('NOTRIED').text();					
		
		$("#ejercicio").append('<div id="inicialte"></div>');
		$("#ejercicio").append('<div id="galeria" class="galeria"><ul id="drag" class="connectedSortable"></ul></div>');
		
		var numDrops = bloquesXML.find('OPTION').length;
		var ancho = (100-(numDrops*3))/numDrops;
		//$('#ejercicio').css({'max-width':1024});		
		if($('#ejercicio').width()>1024){
				$('#ejercicio').css({'width':1024});
		}
		var margen = ($('#enunciadoEjer').outerWidth(true)-$('#ejercicio').outerWidth(true))/2;
		var ejerAncho = ($('#ejercicio').outerWidth(true)*100)/$('#enunciadoEjer').outerWidth(true);
		margen = (100-ejerAncho)/2 + '%';		
		
		$('#ejercicio').css({'margin-left':margen,width:ejerAncho + '%'});
		
		bloquesXML.find('OPTION').each(function(index){
			var respuesta = $(this).text();
			dropsTxt.push(respuesta);
			$("#inicialte").append('<ul id="drop" style="width:'+ancho+'%" class="connectedSortable drop'+index+'"><li class="unsortable roundedTop" style="text-align:center;background-color:#CCC; font-weight:bold;">'+respuesta+'</li></ul>');
        }); 
			
		bloquesXML.find('WORD').each(function(index){
			var respuesta = $(this).text();
			dragsPos.push($(this).attr("col"));
			totDrops++;
			$("#drag").append('<li rel-drop="'+$(this).attr("col")+'" rel-pos="'+index+'">'+respuesta+'</li>');
		}); 
			 
	var randomDragList = shuffle($("#drag").find('li'));
	$("#drag").empty();
	for(i=0;i<randomDragList.length;i++){
		$("#drag").append(randomDragList[i]);
	}
	var conector = ".connectedSortable";
	$( "#drop, #drag" ).sortable({
		connectWith: conector,
		items: "li:not(.unsortable)"
	}).disableSelection();		
	$('#corregir').append('<input name="corrige" id="botCorregir" value="Corregir" class="bot" type="button"/>');
	$( "#galeria" ).css('height',$( "#galeria" ).height());
		
	// boton corregir	
	$("#botCorregir").on("click", function(){ 
		var ok = 0;
		var ko = 0;	
		responsesOkBloques = new Array();
		responsesBloques = new Array();
		$('#inicialte').find('ul').each(function(index){			
			$(this).find('li').each(function(){
				responsesBloques.push($(this).text() + ":" + dropsTxt[index]);
				if($(this).attr('rel-drop')==(index+1)){
					ok++;
					responsesOkBloques[$(this).attr('rel-pos')] = 1;
				}else{
					ko++;
					responsesOkBloques[$(this).attr('rel-pos')] = 0;
				}
			});
		});	
		
		if(ok==0 && ko==0){
			showFeedback("<b>"+fbNT+"</b>");
			return true;
		}
		numOk = ok;
		var nota = parseInt((ok*10)/totDrops);		
		//alert('totDrops:' + totDrops + '\nOk:' + ok + '\nKo:'+ko+' \nNota: ' + nota);			
		if (nota>=NotaCorte){		
			showBloquesSolution();
			sendBloquesNotes(nota);
			showFeedback("<b>"+fbOK+"</b>");
		}else{
			if (intentosBlock == 0) {  showFeedback("<b>"+fb0+"</b>");fbFinal = fb0; }
			if (intentosBlock == 1) { showFeedback("<b>"+fb1+"</b>");fbFinal = fb1; }
			if (intentosBlock == 2) { 					 	
				fbFinal = fb2;
				showBloquesSolution();
				sendBloquesNotes(nota);	
				showFeedback("<b>"+fb2+"</b>");
			}
			intentosBlock++;			
		}
	});
	onExEndLoaded();
}

function showBloquesSolution(){
	addControl('showBloquesSolution');
	$('#inicialte').find('ul').each(function(index){			
			$(this).find('li').each(function(){
				if(!$(this).hasClass('unsortable')){
					$(this).remove();
				}
			});		
	});	
	
	bloquesXML.find('WORD').each(function(index){
			var respuesta = $(this).text();
			var theclass = "";
			if(responsesOkBloques[index]==1){
				theclass="correcto";
			}
			if(responsesOkBloques[index]==0){
				theclass="incorrecto";				
			}
			$(".drop"+(dragsPos[index]-1)).append('<li class="'+theclass+'">'+respuesta+'</li>');
	});
	$('#galeria').empty();
}


function fillBloquesSolution(){	
	$('#inicialte').find('ul').each(function(index){			
			$(this).find('li').each(function(){
				if(!$(this).hasClass('unsortable')){
					$(this).remove();
				}
			});		
	});	
		
	bloquesXML.find('WORD').each(function(index){
		 var respuesta = $(this).text();
		$(".drop"+(dragsPos[index]-1)).append('<li>'+respuesta+'</li>');
	});
	
	$('#inicialte').find('ul').each(function(index){			
			$(this).find('li').each(function(){	
				if(!$(this).hasClass('unsortable')){							 
					$(this).attr('rel-drop',(index+1));
				}
			});
		});	
	//addControl('responsesOkBloques : ' + responsesOkBloques);
	//showBloquesSolution();
	
}

function sendBloquesNotes(nota){	 
	$('#botCorregir').remove();	
	showResults(numOk,totDrops,intentosBlock+1,nota);
	exercisesNotes[actvPage] = nota;
	exercisesInter[actvPage]= responsesBloques;
	exercisesOk[actvPage]= responsesOkBloques;
	sendNota();
	return true;
}


function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex ;
  while (0 !== currentIndex) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  return array;
}
